package View;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */

import Controller.ReserveController;

public class Reserve extends javax.swing.JPanel {

    /**
     * Creates new form CSC319_Reserve
     */
    ReserveController control;
    
    public Reserve(ReserveController r) {
        this.control = r;
        setBounds(0,0,600,600);
        initComponents();
        initButton();
    }

    
/*private int removeComma(String str) {
        int num = 0;
        try {
            java.text.NumberFormat format = java.text.NumberFormat.getInstance(java.util.Locale.getDefault());
            Number number = format.parse(str);
            num = number.intValue();
        } catch (java.text.ParseException e) {
        }
        return num;
    }
    */

    public Reserve() {
       initComponents();
    }

//private static Queuing queue;
    private boolean clickedEnter, clickedADay, clickedAMonth;

    private static int tableId;
    private static java.sql.Timestamp dateTimeReserve, timeOut;
    private int customerId;

private void delectSelectedRow(javax.swing.JTable tbl, javax.swing.JLabel lbl, int row) {
        int res = javax.swing.JOptionPane.showConfirmDialog(null, "Are you sure you want to delete row " + (tbl.getSelectedRow() + 1) + " ?", "Please Confirm", javax.swing.JOptionPane.YES_NO_OPTION);
        switch (res) {

            case javax.swing.JOptionPane.YES_OPTION:
                javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tbl.getModel();

                computePrice(lbl, control.removeComma(String.valueOf(model.getValueAt(row, 4))), "-");
                computePrice(lblTotalPrice, control.removeComma(String.valueOf(model.getValueAt(row, 4))), "-");

                model.removeRow(row);
                
                for (int i = row; i < model.getRowCount(); i++) {
                    model.setValueAt(i+1 , i, 0);
                }

                javax.swing.JOptionPane.showMessageDialog(null, "Delete Successfully");
                break;

            case javax.swing.JOptionPane.NO_OPTION:
                javax.swing.JOptionPane.showMessageDialog(null, "Delete Action is Canceled");
                break;
        }
        
    } 
private String putComma(double num) {
        String s = String.valueOf(num);
        String res = "";
        if (s.length() <= 5) {
            return s + "0.-";
        } else {
            int cnt = 0;
            for (int i = s.length() - 3; i >= 0; i--) {
                cnt++;
                res = s.charAt(i) + res;
                if (cnt == 3 && i > 0) {
                    res = "," + res;
                    cnt = 0;
                }
            }
            return res + ".00.-";
        }
    }
private void computePrice(javax.swing.JLabel label, double price, String sign) {
        double totalPrice = 0;
        if (label.getText().equals("")) {
            totalPrice = price;
        } else {
            switch (sign) {
                case "+":
                    totalPrice = control.removeComma(String.valueOf(label.getText())) + price;
                    break;
                case "-":
                    totalPrice = control.removeComma(String.valueOf(label.getText())) - price;
            }
        }
        if (totalPrice == 0) {
            label.setText("");
        } else {
            label.setText(putComma(totalPrice));
        }
    }       
public void addtblBeverageMenuLine(javax.swing.JButton btn, double price) {
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tblBeverageMenu.getModel();
         int i = 0;

        for (i = 0; i < model.getRowCount(); i++) {
            if (btn.getText().equals(model.getValueAt(i, 1))) {
                model.setValueAt(Integer.parseInt(String.valueOf((model.getValueAt(i, 3)))) + 1, i, 3);
                model.setValueAt(putComma(price * control.removeComma(String.valueOf(model.getValueAt(i, 3)))), i, 4);
                break;
            }
        }

        if (model.getRowCount() == 0 || i >= model.getRowCount()) {
            model.addRow(new Object[0]);
            tblBeverageMenu.setValueAt(model.getRowCount(), model.getRowCount()-1, 0);
            tblBeverageMenu.setValueAt(btn.getText(), model.getRowCount()-1, 1);
            tblBeverageMenu.setValueAt(price + "0.-", model.getRowCount()-1, 2);
            tblBeverageMenu.setValueAt(1, model.getRowCount()-1, 3);
            tblBeverageMenu.setValueAt(price + "0.-", model.getRowCount()-1, 4);
        }

        computePrice(lblTotalBeveragePrice, price, "+");
        computePrice(lblTotalPrice, price, "+");
            }

public void addtblFoodMenuLine(javax.swing.JButton btn, double price) {
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tblFoodMenu.getModel();
        int i = 0;

        for (i = 0; i < model.getRowCount(); i++) {
            if (btn.getText().equals(model.getValueAt(i, 1))) {
                model.setValueAt(Integer.parseInt(String.valueOf((model.getValueAt(i, 3)))) + 1, i, 3);
                model.setValueAt(putComma(price * control.removeComma(String.valueOf(model.getValueAt(i, 3)))), i, 4);
                break;
            }
        }

        if (model.getRowCount() == 0 || i >= model.getRowCount()) {
            model.addRow(new Object[0]);
            tblFoodMenu.setValueAt(model.getRowCount(), model.getRowCount()-1, 0);
            tblFoodMenu.setValueAt(btn.getText(), model.getRowCount()-1, 1);
            tblFoodMenu.setValueAt(price + "0.-", model.getRowCount()-1, 2);
            tblFoodMenu.setValueAt(1, model.getRowCount()-1, 3);
            tblFoodMenu.setValueAt(price + "0.-", model.getRowCount()-1, 4);
        }

        computePrice(lblTotalFoodPrice, price, "+");
        computePrice(lblTotalPrice, price, "+");
    }
private void setOrders(int line, javax.swing.JTable tbl) {
        for (int i = 0; i < line; i++) {
            String foodName = String.valueOf(tbl.getValueAt(i, 1));
            int qty = Integer.parseInt(String.valueOf(tbl.getValueAt(i, 3)));
            String reserve = dateTimeReserve.toString().substring(0, dateTimeReserve.toString().length() - 2);
            String out = timeOut.toString().substring(0, timeOut.toString().length() - 2);
           // queue.insertOrders(reserve, out, queue.getFoodId(foodName), qty, tableId, customerId);
        }
    }  

private void resetToDefault() {
        tableId = customerId = -1;
        dateTimeReserve = timeOut = null;
        lblTableNo.setText("");
        lblReserve.setText("");
        txtName.setText("");
        lblTotalBeveragePrice.setText("");
        lblTotalFoodPrice.setText("");
        lblTotalPrice.setText("");
        deleteAllRow((javax.swing.table.DefaultTableModel) tblFoodMenu.getModel());
        deleteAllRow((javax.swing.table.DefaultTableModel) tblBeverageMenu.getModel());
    }   
private void deleteAllRow(javax.swing.table.DefaultTableModel model) {
        for (int i = model.getRowCount() - 1; i >= 0; i--) {
            model.removeRow(i);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    private Snack s;
    private void initButton(){
        s = new Snack();
        jPanel1.add(s);
        
    }
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBeverageMenu = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblFoodMenu = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        lblTotalBeveragePrice = new javax.swing.JLabel();
        lblTotalFoodPrice = new javax.swing.JLabel();
        lblTotalPrice = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblTableNo = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lblReserve = new javax.swing.JLabel();
        btndone = new javax.swing.JButton();
        btnclear = new javax.swing.JButton();

        jButton1.setText("Check Table");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setText("NAME :");

        txtName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNameActionPerformed(evt);
            }
        });

        jButton2.setText("Snack");

        jButton3.setText("Foods");

        jButton4.setText("Baverage");

        tblBeverageMenu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                " No", "Foods", "Price", "Qty", "Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblBeverageMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBeverageMenuMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblBeverageMenu);
        if (tblBeverageMenu.getColumnModel().getColumnCount() > 0) {
            tblBeverageMenu.getColumnModel().getColumn(4).setResizable(false);
        }

        tblFoodMenu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Beverage", "Price", "Qty", "Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblFoodMenu);

        jButton6.setText("snack1");
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton6MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jButton6)
                .addContainerGap(299, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jButton6)
                .addContainerGap(361, Short.MAX_VALUE))
        );

        lblTotalBeveragePrice.setText("Total");

        lblTotalFoodPrice.setText("Total");

        lblTotalPrice.setText("Total");

        jLabel2.setText("Table No :");

        jLabel4.setText("Reserve No :");

        lblReserve.setText("       ");

        btndone.setText("Done");
        btndone.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btndoneMouseClicked(evt);
            }
        });
        btndone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndoneActionPerformed(evt);
            }
        });

        btnclear.setText("Clear");
        btnclear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnclearMouseClicked(evt);
            }
        });
        btnclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(114, 114, 114)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(lblTableNo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblReserve, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTotalBeveragePrice, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(6, 6, 6)
                            .addComponent(lblTotalFoodPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addComponent(lblTotalPrice, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(btndone, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(btnclear, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTotalBeveragePrice)
                        .addGap(35, 35, 35)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTotalFoodPrice)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTotalPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btndone, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnclear, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(lblTableNo, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(lblReserve))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(83, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNameActionPerformed

    
    private void jButton6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseClicked
        // TODO add your handling code here:
         addtblBeverageMenuLine(jButton6, 15.0);
    }//GEN-LAST:event_jButton6MouseClicked

    private void tblBeverageMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBeverageMenuMouseClicked

                if (evt.getClickCount() == 2) {
                    int row = tblBeverageMenu.getSelectedRow(); // extend JFrame
                    delectSelectedRow(tblBeverageMenu, lblTotalBeveragePrice, row);
                }
    }//GEN-LAST:event_tblBeverageMenuMouseClicked

    private void btnclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btnclearActionPerformed

    private void btndoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btndoneActionPerformed

    private void btndoneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btndoneMouseClicked
        // TODO add your handling code here:
         if (lblTableNo.getText().equals("") || lblReserve.getText().equals("")) {
                    javax.swing.JOptionPane.showMessageDialog(null, "Please select table No. and time reserve");
                } else if (txtName.getText().equals("")) {
                    javax.swing.JOptionPane.showMessageDialog(null, "Please input customer's name");
                } else if (tblFoodMenu.getRowCount() == 0 && tblBeverageMenu.getRowCount() == 0) {
                    javax.swing.JOptionPane.showMessageDialog(null, "Please select orders");
                } else {
                    //customerId = queue.getCustomerId(txtName.getText());
                    setOrders(tblFoodMenu.getRowCount(), tblFoodMenu);
                    setOrders(tblBeverageMenu.getRowCount(), tblBeverageMenu);
                    //queue.updateStatusTable(tableId);
                    resetToDefault();
                    javax.swing.JOptionPane.showMessageDialog(null, "Successfully");
                }
    }//GEN-LAST:event_btndoneMouseClicked

    private void btnclearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnclearMouseClicked
        // TODO add your handling code here:
         
                resetToDefault();
            
    }//GEN-LAST:event_btnclearMouseClicked
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnclear;
    private javax.swing.JButton btndone;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblReserve;
    private javax.swing.JLabel lblTableNo;
    private javax.swing.JLabel lblTotalBeveragePrice;
    private javax.swing.JLabel lblTotalFoodPrice;
    private javax.swing.JLabel lblTotalPrice;
    private javax.swing.JTable tblBeverageMenu;
    private javax.swing.JTable tblFoodMenu;
    private javax.swing.JTextField txtName;
    // End of variables declaration//GEN-END:variables

  
}

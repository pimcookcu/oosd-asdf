/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;
/**
 *
 * @author pim
 * 
 */
import edu.sit.cs.db.CSDbDelegate;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

/**
 *
 * @author pim
 */
public class BacklogQuery {
    private static CSDbDelegate db;
     
    public BacklogQuery() {
        db = new CSDbDelegate("csprog-in.sit.kmutt.ac.th", "3306", "CSC105_G5", "csc105_2014", "csc105");
        System.out.println(db.connect());
    }
    
    //Backlog
    public ArrayList<HashMap> getBacklogADay(String date) {
        String sql = "SELECT * FROM R_BACKLOG";
        ArrayList<HashMap> backlogs = db.queryRows(sql);

        double total = 0;
        ArrayList<HashMap> aday = new ArrayList<HashMap>();

        for (HashMap backlog : backlogs) {
            String s = String.valueOf(backlog.get("date")).substring(0, 7);

            if (s.equals(date)) {
                total += Double.parseDouble(String.valueOf(backlog.get("revenue")));
                HashMap<String, Object> hashMap = new HashMap<String, Object>();
                hashMap.put("date", String.valueOf(backlog.get("date")));
                hashMap.put("noOfCustomer", String.valueOf(backlog.get("noOfCustomer")));
                hashMap.put("revenue", String.valueOf(backlog.get("revenue")));
                hashMap.put("total", total);

                aday.add(hashMap);
            }
        }

        return aday;
    }
    
}

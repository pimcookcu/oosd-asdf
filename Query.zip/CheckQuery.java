/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;
/**
 *
 * @author pim
 * 
 */
import edu.sit.cs.db.CSDbDelegate;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

/**
 *
 * @author pim
 */
public class CheckQuery {
    private static CSDbDelegate db;
     
    public CheckQuery() {
        db = new CSDbDelegate("csprog-in.sit.kmutt.ac.th", "3306", "CSC105_G5", "csc105_2014", "csc105");
        System.out.println(db.connect());
    }
    //CheckAvailable class
    public int checkAvailable(Date date, Date time, int chairs) throws ParseException {
        int tableId = -1;

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        DateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        String reserve = dateFormat.format(date) + " " + timeFormat.format(time);
        Calendar dateTimeReserve = new GregorianCalendar();
        dateTimeReserve.setTime(dateTimeFormat.parse(reserve));
        dateTimeReserve.add(Calendar.YEAR, -543);

        Calendar currentTime = new GregorianCalendar();
        currentTime.add(Calendar.YEAR, -543);
        currentTime.add(Calendar.MINUTE, 59);

        Calendar openTime = new GregorianCalendar();
        openTime.setTime(timeFormat.parse("07:59"));

        Calendar closeTime = new GregorianCalendar();
        closeTime.setTime(timeFormat.parse("20:01"));

        boolean beforeOneHour = dateTimeReserve.getTime().before(currentTime.getTime());
        boolean beforeOpen = time.before(openTime.getTime());
        boolean afterClose = time.after(closeTime.getTime());

        if (beforeOneHour) {
            return -3;
        }

        if (beforeOpen || afterClose) {
            return -2;
        }

        String tableIdSql = "SELECT tableID, available FROM R_TABLES WHERE chairs = " + chairs;
        ArrayList<HashMap> tables = db.queryRows(tableIdSql);

        for (HashMap table : tables) {
            if (Integer.parseInt(String.valueOf(table.get("available"))) == 1) {
                tableId = Integer.parseInt(String.valueOf(table.get("tableID")));
                //CheckAvailable.setDateTimeReserve(dateTimeReserve);
                return tableId;
            }
        }

        if (tableId == -1) {
            for (HashMap table : tables) {
                tableIdSql = "SELECT dateTimeReserve, tableID FROM R_ORDERS WHERE tableID = " + table.get("tableID");
                HashMap tables2 = db.queryRow(tableIdSql);

                Calendar minDate = new GregorianCalendar();
                minDate.setTime(dateTimeFormat.parse(String.valueOf(tables2.get("dateTimeReserve"))));
                minDate.add(Calendar.HOUR_OF_DAY, -2);

                Calendar maxDate = new GregorianCalendar();
                maxDate.setTime(dateTimeFormat.parse(String.valueOf(tables2.get("dateTimeReserve"))));
                maxDate.add(Calendar.HOUR_OF_DAY, 2);

                if (dateTimeReserve.getTime().before(minDate.getTime()) || dateTimeReserve.getTime().after(maxDate.getTime())) {
                    tableId = Integer.parseInt(String.valueOf(tables2.get("tableID")));
                    //CheckAvailable.setDateTimeReserve(dateTimeReserve);
                    return tableId;
                }
            }
        }
        //CheckAvailable.setDateTimeReserve(dateTimeReserve);
        return tableId;
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
/**
 *
 * @author pim
 * 
 */
import edu.sit.cs.db.CSDbDelegate;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

public class ReserveQuery {
    private static CSDbDelegate db;
     
    public ReserveQuery() {
        db = new CSDbDelegate("csprog-in.sit.kmutt.ac.th", "3306", "CSC105_G5", "csc105_2014", "csc105");
        System.out.println(db.connect());
    }
      //meth.setOrders --> Reserve
    public int getFoodId(String foodName) {
        String sql = "SELECT foodID FROM R_FOODS WHERE foodName = '" + foodName + "'";
        HashMap foodId = db.queryRow(sql);
        return Integer.parseInt(String.valueOf(foodId.get("foodID")));
    }
    //medt.addPopularFood --- Reserve
    public ArrayList<HashMap> getPopularSnacks() {
        String sql = "SELECT foodName FROM R_FOODS WHERE foodID > 300 ORDER BY ordered DESC";
        return db.queryRows(sql);
    }
    
    //meth setOrders -reserve
    public void insertOrders(String dateTimeReserve, String timeOut, int foodId, int quantity, int tableId, int customerId) {
        String sql = "INSERT INTO R_ORDERS(dateTimeReserve, timeOut, foodID, quantity, tableID, customerID) VALUES ( '"
                + dateTimeReserve + " ', '"
                + timeOut + " ', "
                + foodId + ", "
                + quantity + ", "
                + tableId + ", "
                + customerId
                + " )";
        db.executeQuery(sql);
    }
    
    //Reserve
    public void updateStatusTable(int tableId) {
        String sql = "UPDATE R_TABLES SET available = false WHERE tableID = " + tableId;
        db.executeQuery(sql);
    }
    //Reserve
    public int getCustomerId(String name) {
        String sql = "SELECT * FROM R_CUSTOMERS";
        ArrayList<HashMap> customers = db.queryRows(sql);

        for (HashMap customer : customers) {
            if (customer.get("customerName").equals(name)) {
                return Integer.parseInt(String.valueOf(customer.get("customerID")));
            }
        }

        sql = "INSERT INTO R_CUSTOMERS(customerID, customerName) VALUES("
                + (customers.size() + 1) + ", '"
                + name + "' "
                + ")";
        db.executeQuery(sql);
        return customers.size() + 1;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;
import javax.swing.JLabel;

/**
 *
 * @author Student Lab
 */
public class BillingController extends Delete{
    
    public int removeComma(String str) {
        int num = 0;
        try {
            NumberFormat format = NumberFormat.getInstance(Locale.getDefault());
            Number number = format.parse(str);
            num = number.intValue();
        } catch (ParseException e) { }
        return num;
    }
        
    public String putComma(double num) {
        String s = String.valueOf(num);
        String res = "";
        if (s.length() <= 5) {
            return s + "0.-";
        } else {
            int cnt = 0;
            for (int i = s.length() - 3; i >= 0; i--) {
                cnt++;
                res = s.charAt(i) + res;
                if (cnt == 3 && i > 0) {
                    res = "," + res;
                    cnt = 0;
                }
            }
            return res + ".00.-";
        }
    }
        
    public void computePrice(JLabel label, double price, String sign) {
        double totalPrice = 0;
        if (label.getText().equals("")) {
            totalPrice = price;
        } else {
            switch (sign) {
                case "+":
                    totalPrice = removeComma(String.valueOf(label.getText())) + price;
                    break;
                case "-":
                    totalPrice = removeComma(String.valueOf(label.getText())) - price;
            }
        }
        if (totalPrice == 0) {
            label.setText("");
        } else {
            label.setText(putComma(totalPrice));
        }
    }
    
}

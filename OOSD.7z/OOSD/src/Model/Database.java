/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import edu.sit.cs.db.CSDbDelegate;
/**
 *
 * @author BestDark
 */
public class Database {
    private CSDbDelegate db;
     
    public void connect(){
        try{
            //db = new CSDbDelegate ("","","","","");
            db.connect();
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
    }
    
    public void disconnect(){
        try{
            db.disconnect();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
 
    public void excute(String sql){
        try{
            db.executeQuery(sql);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import View.CheckTable;
import Model.*;
import java.awt.Color;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JSpinner;

/**
 *
 * @author BestDark
 */
public class CheckTableController extends Delete{
    
    Query q;
    
    public void setDateTimeReserve(Calendar time, Calendar date) {
        date.setTime(time.getTime());
    }
    
    public void chairsMouseClicked(int chairs, JLabel message, JSpinner date, JSpinner time, String[] s, int id) {
        message.setText("");
        try {  
            int tableId = q.checkAvailable((Date)date.getValue(), (Date)time.getValue(), chairs);
            
            switch(tableId) {
                case -1 :
                    message.setText(s[1]);
                    message.setForeground(new Color(255, 0, 0));
                    break;
                case -2 :
                    message.setText(s[3]);
                    message.setForeground(new Color(255, 0, 0));
                    break;
                case -3 :                    
                    message.setText("<HTML><I>" + s[2] + "</I></HTML>");
                    message.setForeground(new Color(255, 0, 0));
                    break;
                default :
                    message.setText(s[0] + tableId);
                    message.setForeground(new Color(0, 204, 0));
                    id = tableId;
            }
        } catch (ParseException ex) {
            Logger.getLogger(CheckTable.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}

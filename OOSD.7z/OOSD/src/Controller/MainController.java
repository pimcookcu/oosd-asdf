/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author BestDark
 */
import Model.*;
import View.*;
import java.sql.Timestamp;
import javax.swing.JPanel;

public class MainController {
    Frame frame;
    CheckTable secFrame;
    
    public void run(){
        frame = new Frame(new Main(this));
    }
    
    public void goToReserve(){
        frame.changeCurrent(new Reserve(new ReserveController(), new MainController()));
    }
    
    public void goToBilling(){
        frame.changeCurrent(new Billing(new BillingController()));//billing
    }
    
    public void goToBacklog(){
        frame.changeCurrent(new Backlog(new BacklogController()));//backlog
    }
    
    public void addCheckTable(){
       secFrame = new CheckTable(new CheckTableController());
    }
    
}

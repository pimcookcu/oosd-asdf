/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author BestDark
 */
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JSpinner;

public class BillingController extends Delete{
            
    public void addNumber(boolean enter, JLabel l, JButton b){
        if (!enter) {
            l.setText(putComma(Double.parseDouble((removeComma(l.getText()) + b.getText()))));
        }
    }
    public void removeNumber(boolean enter, JLabel l){
        if (!enter) {
            String text = String.valueOf(removeComma(l.getText()));
            if (text.length() <= 1) {
                l.setText("");
            } else {
                text = text.substring(0, text.length() - 1);
                l.setText(putComma(Double.parseDouble(text)));
            }
        }
    }
    
    public void checkEnter(boolean enter, JLabel cash, JLabel lchange, JLabel t){
        double change = removeComma(cash.getText()) - removeComma(t.getText());
                if(cash.getText().equals("") || t.getText().equals("")) {
                } else if (change < 0.0) {
                    javax.swing.JOptionPane.showMessageDialog(null, "Not Enough");
                } else {
                    lchange.setText(putComma(change));
                    enter = true;
                }
    }
    
    public void discount(JLabel t, int a){
        double total = a * removeComma(t.getText()) / 100;
        t.setText(putComma(total));
    }
    
    public void checkDone(JSpinner d){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar date = new GregorianCalendar();
        date.setTime((Date) d.getValue());
        date.add(java.util.Calendar.YEAR, -543);
        //queue.removeOrders(dateFormat.format(date.getTime()) + " " + String.valueOf(lbldateTime.getText()).substring(16), Integer.parseInt(lblTable.getText().substring(4)));
        //queue.updateBacklog(dateFormat.format(date.getTime()), removeComma(lblTotal.getText()), Integer.parseInt(lblTable.getText().substring(4))/100);
        //updatePopularFood();
    }
}

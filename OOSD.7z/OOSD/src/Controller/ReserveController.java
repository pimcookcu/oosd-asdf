/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author BestDark
 */
public class ReserveController extends Delete{
    BillingController c;
    String s = "";

    public void addtblMenuLine(JLabel tp, JLabel fp, JTable t, JButton btn, double price) {//addFoodsButton, addBevaragesButton
        DefaultTableModel model = (DefaultTableModel) t.getModel();
        int i = 0;

        for (i = 0; i < model.getRowCount(); i++) {
        if (btn.getText().equals(model.getValueAt(i, 1))) {
            model.setValueAt(Integer.parseInt(String.valueOf((model.getValueAt(i, 3)))) + 1, i, 3);
            model.setValueAt(c.putComma(price * c.removeComma(String.valueOf(model.getValueAt(i, 3)))), i, 4);
            break;
        }
    }

        if (model.getRowCount() == 0 || i >= model.getRowCount()) {
            model.addRow(new Object[0]);
            t.setValueAt(model.getRowCount(), model.getRowCount()-1, 0);
            t.setValueAt(btn.getText(), model.getRowCount()-1, 1);
            t.setValueAt(price + "0.-", model.getRowCount()-1, 2);
            t.setValueAt(1, model.getRowCount()-1, 3);
            t.setValueAt(price + "0.-", model.getRowCount()-1, 4);
        }

        c.computePrice(fp, price, "+");
        c.computePrice(tp, price, "+");
    }

    public void delectSelectedRow(JTable tbl, JLabel lbl, JLabel lblPrice, int row) {
        int res = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete row " + (tbl.getSelectedRow() + 1) + " ?", "Please Confirm", JOptionPane.YES_NO_OPTION);
        switch (res) {
            case JOptionPane.YES_OPTION:
                
                DefaultTableModel model = (DefaultTableModel) tbl.getModel();

                c.computePrice(lbl, c.removeComma(String.valueOf(model.getValueAt(row, 4))), "-");
                c.computePrice(lblPrice, c.removeComma(String.valueOf(model.getValueAt(row, 4))), "-");

                model.removeRow(row);
                
                for (int i = row; i < model.getRowCount(); i++) {
                    model.setValueAt(i+1 , i, 0);
                }

                JOptionPane.showMessageDialog(null, "Delete Successfully");
                break;

            case JOptionPane.NO_OPTION:
                JOptionPane.showMessageDialog(null, "Delete Action is Canceled");
                break;
        }
    }    
    
    public void setOrders(int line, JTable tbl, Timestamp timeReserve, Timestamp timeOut, int tabId, int cusId) {
        for (int i = 0; i < line; i++) {
            String foodName = String.valueOf(tbl.getValueAt(i, 1));
            int qty = Integer.parseInt(String.valueOf(tbl.getValueAt(i, 3)));
            String reserve = timeReserve.toString().substring(0, timeReserve.toString().length() - 2);//dateTimeReserve
            String out = timeOut.toString().substring(0, timeOut.toString().length() - 2);
            q.insertOrders(reserve, out, q.getFoodId(foodName), qty, tabId, cusId);//tableId customerId
        }
    }
    
    public String currentTime() {        
        Timer timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                DateFormat timeFormat = new SimpleDateFormat("dd-MM-yyyy   HH:mm:ss");
                Calendar currentTime = new GregorianCalendar();
                currentTime.add(Calendar.YEAR, -543);
                //clock.setText(timeFormat.format(currentTime.getTime()));
                s = timeFormat.format(currentTime.getTime());
            }
        });
        timer.start();
        return s;//clock.settext
    }
    
}

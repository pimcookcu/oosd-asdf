/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Query;
import java.sql.Timestamp;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author BestDark
 */
public abstract class Delete {
    Query q;
    
    public void deleteAllRow(DefaultTableModel model) {
        for (int i = model.getRowCount() - 1; i >= 0; i--) {
            model.removeRow(i);
        }
    } 
    
    public void checkTable(JSpinner s, JTable t) {
        ArrayList<HashMap> tables = q.getOrders((Date) (s.getValue()));//spnDate
        DefaultTableModel model = (DefaultTableModel) t.getModel();//tblgetTables
        deleteAllRow(model);
        int line = 0;
        if (tables != null) {
            for (HashMap table : tables) {
                model.addRow(new Object[0]);
                model.setValueAt(Integer.parseInt(String.valueOf(table.get("tableID"))), line, 0);
                model.setValueAt(q.getCustomerName(Integer.parseInt(String.valueOf(table.get("customerID")))), line, 1);
                model.setValueAt(String.valueOf(table.get("dateTimeReserve")).substring(11, 19), line, 2);
                model.setValueAt(String.valueOf(table.get("timeOut")).substring(11, 19), line, 3);
                line++;
            }
        }
    }
    
    public void setTableIdAndTime(int id, Calendar time, Timestamp timeReserve, Timestamp timeOut, int tabId) {
        tabId = id;
        time.add(Calendar.YEAR, 543);
        timeReserve = new Timestamp(time.getTimeInMillis());
        time.add(Calendar.MINUTE, 90);
        timeOut = new Timestamp(time.getTimeInMillis());
    }

    public void setLabelDateAndTime(String tableNo, String time, JLabel tableNum, JLabel reserve) {
        tableNum.setText("");
        reserve.setText("");

        tableNum.setText(tableNo);
        reserve.setText(time);
    }
    
    public String putComma(double num) {
        String s = String.valueOf(num);
        String res = "";
        if (s.length() <= 5) {
            return s + "0.-";
        } else {
            int cnt = 0;
            for (int i = s.length() - 3; i >= 0; i--) {
                cnt++;
                res = s.charAt(i) + res;
                if (cnt == 3 && i > 0) {
                    res = "," + res;
                    cnt = 0;
                }
            }
            return res + ".00.-";
        }
    }
    
    public int removeComma(String str) {
        int num = 0;
        try {
            NumberFormat format = NumberFormat.getInstance(Locale.getDefault());
            Number number = format.parse(str);
            num = number.intValue();
        } catch (ParseException e) { }
        return num;
    }
    
    public void computePrice(JLabel label, double price, String sign) {
        double totalPrice = 0;
        if (label.getText().equals("")) {
            totalPrice = price;
        } else {
            switch (sign) {
                case "+":
                    totalPrice = removeComma(String.valueOf(label.getText())) + price;
                    break;
                case "-":
                    totalPrice = removeComma(String.valueOf(label.getText())) - price;
            }
        }
        if (totalPrice == 0) {
            label.setText("");
        } else {
            label.setText(putComma(totalPrice));
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author BestDark
 */
public class BacklogController extends Delete{
    public void checkMonthOrDay(JSpinner spnB, boolean day, boolean month, boolean check){
        JSpinner.DateEditor dateEditor = null;
        if(check){
            dateEditor = new JSpinner.DateEditor(spnB, "MMMMM yyyy");
            day = true;
            month = false;
        }else{
            dateEditor = new JSpinner.DateEditor(spnB, "yyyy");
            day = false;
            month = true;
        }
        spnB.setEditor(dateEditor);
        ((JSpinner.DefaultEditor)spnB.getEditor()).getTextField().setHorizontalAlignment(javax.swing.JTextField.RIGHT);
    }
    
    public void backlogCheckClick(JSpinner spnB, boolean day, boolean month,JTable t){
        deleteAllRow((javax.swing.table.DefaultTableModel) t.getModel());
        ArrayList<java.util.HashMap> logs = null;
        if(day) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
        }
        if(month) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
        }
        Calendar date = new GregorianCalendar();
        date.setTime((Date) spnB.getValue());
        date.add(java.util.Calendar.YEAR, -543);
        //logs = queue.getBacklogADay(dateFormat.format(date.getTime()));
        int line = 0;
            for(java.util.HashMap log : logs) {
                DefaultTableModel model = (DefaultTableModel) t.getModel();
                model.addRow(new Object[0]);
                model.setValueAt(log.get("date"), line, 0);
                model.setValueAt(log.get("noOfCustomer"), line, 1);
                model.setValueAt(putComma(Double.parseDouble(String.valueOf(log.get("revenue")))), line, 2);
                model.setValueAt(putComma(Double.parseDouble(String.valueOf(log.get("total")))), line, 3);
                line++;
            }
    }
}

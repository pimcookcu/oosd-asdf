/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.*;
import View.*;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author BestDark
 */
public class Controller {
    
    Frame frame;

    
    public void run(){
        frame = new Frame(new Main(this));
    }
    
    public void goToMain(){
        frame.changeCurrent(new Main(this));
    }
    
    public void setButtonMenu(JLabel tp, JLabel fp, JTable t, JButton btn, String s, int x, int y, double i){
        btn.setText(s);
        btn.setToolTipText(s);
        btn.setPreferredSize(new Dimension(x, y));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                addtblFoodMenuLine(tp, fp, t, btn, i);
            }
        });
    }    
    
    public void addtblFoodMenuLine(JLabel tp, JLabel fp, JTable t, JButton btn, double price) {
        DefaultTableModel model = (DefaultTableModel) t.getModel();
        int i = 0;

        for (i = 0; i < model.getRowCount(); i++) {
            if (btn.getText().equals(model.getValueAt(i, 1))) {
                model.setValueAt(Integer.parseInt(String.valueOf((model.getValueAt(i, 3)))) + 1, i, 3);
                model.setValueAt(putComma(price * removeComma(String.valueOf(model.getValueAt(i, 3)))), i, 4);
                break;
            }
        }

        if (model.getRowCount() == 0 || i >= model.getRowCount()) {
            model.addRow(new Object[0]);
            t.setValueAt(model.getRowCount(), model.getRowCount()-1, 0);
            t.setValueAt(btn.getText(), model.getRowCount()-1, 1);
            t.setValueAt(price + "0.-", model.getRowCount()-1, 2);
            t.setValueAt(1, model.getRowCount()-1, 3);
            t.setValueAt(price + "0.-", model.getRowCount()-1, 4);
        }

        computePrice(fp, price, "+");
        computePrice(tp, price, "+");
    }
           
    private int removeComma(String str) {
        int num = 0;
        try {
            NumberFormat format = NumberFormat.getInstance(Locale.getDefault());
            Number number = format.parse(str);
            num = number.intValue();
        } catch (ParseException e) { }
        return num;
    }
        
    private String putComma(double num) {
        String s = String.valueOf(num);
        String res = "";
        if (s.length() <= 5) {
            return s + "0.-";
        } else {
            int cnt = 0;
            for (int i = s.length() - 3; i >= 0; i--) {
                cnt++;
                res = s.charAt(i) + res;
                if (cnt == 3 && i > 0) {
                    res = "," + res;
                    cnt = 0;
                }
            }
            return res + ".00.-";
        }
    }
        
    public void computePrice(JLabel label, double price, String sign) {
        double totalPrice = 0;
        if (label.getText().equals("")) {
            totalPrice = price;
        } else {
            switch (sign) {
                case "+":
                    totalPrice = removeComma(String.valueOf(label.getText())) + price;
                    break;
                case "-":
                    totalPrice = removeComma(String.valueOf(label.getText())) - price;
            }
        }
        if (totalPrice == 0) {
            label.setText("");
        } else {
            label.setText(putComma(totalPrice));
        }
    }
}

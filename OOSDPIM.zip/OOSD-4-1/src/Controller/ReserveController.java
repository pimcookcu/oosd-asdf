package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

public class ReserveController extends Delete {

    BillingController c;
    String s = "";

    public void addtblMenuLine(JLabel tp, JLabel fp, JTable t, JButton btn, double price) {//addFoodsButton, addBevaragesButton
        DefaultTableModel model = (DefaultTableModel) t.getModel();
        int i = 0;

        for (i = 0; i < model.getRowCount(); i++) {
            if (btn.getText().equals(model.getValueAt(i, 1))) {
                model.setValueAt(Integer.parseInt(String.valueOf((model.getValueAt(i, 3)))) + 1, i, 3);
                model.setValueAt(price * ((int) model.getValueAt(i, 3)), i, 4);
                break;
            }
        }

        if (model.getRowCount() == 0 || i >= model.getRowCount()) {
            model.addRow(new Object[0]);
            t.setValueAt(model.getRowCount(), model.getRowCount() - 1, 0);
            t.setValueAt(btn.getText(), model.getRowCount() - 1, 1);
            t.setValueAt(price, model.getRowCount() - 1, 2);
            t.setValueAt(1, model.getRowCount() - 1, 3);
            t.setValueAt(price, model.getRowCount() - 1, 4);
        }

        tp.setText("" + (Double.parseDouble(tp.getText()) + price));
        fp.setText("" + (Double.parseDouble(fp.getText()) + price));
    }

    public void delectSelectedRow(JTable table, JLabel lblFoodPrice, JLabel lblTotalPrice, int row) {

        int res = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete row " + (table.getSelectedRow() + 1) + " ?", "Please Confirm", JOptionPane.YES_NO_OPTION);
        switch (res) {
            case JOptionPane.YES_OPTION:

                DefaultTableModel model = (DefaultTableModel) table.getModel();
                double price = (double) table.getModel().getValueAt(row, 4);
                double foodPrice = Double.parseDouble(lblFoodPrice.getText());
                double totalPrice = Double.parseDouble(lblTotalPrice.getText());
                lblFoodPrice.setText("" + (totalPrice - price));
                lblTotalPrice.setText("" + (totalPrice - price));
                
                model.removeRow(row);

                // FIX NO
                for (int i = row; i < model.getRowCount(); i++) {
                    model.setValueAt(i + 1, i, 0);
                }

                JOptionPane.showMessageDialog(null, "Delete Successfully");
                break;

            case JOptionPane.NO_OPTION:
                JOptionPane.showMessageDialog(null, "Delete Action is Canceled");
                break;
        }
    }

    public void setOrders(int line, JTable tbl, Timestamp timeReserve, Timestamp timeOut, int tabId, int cusId) {
        for (int i = 0; i < line; i++) {
            String foodName = String.valueOf(tbl.getValueAt(i, 1));
            int qty = Integer.parseInt(String.valueOf(tbl.getValueAt(i, 3)));
            String reserve = timeReserve.toString().substring(0, timeReserve.toString().length() - 2);//dateTimeReserve
            String out = timeOut.toString().substring(0, timeOut.toString().length() - 2);
            q.insertOrders(reserve, out, q.getFoodId(foodName), qty, tabId, cusId);//tableId customerId
        }
    }

    public void setTableIdAndTime(int id, Calendar time, Timestamp timeReserve, Timestamp timeOut, int tabId) {
        tabId = id;
        time.add(Calendar.YEAR, 543);
        timeReserve = new Timestamp(time.getTimeInMillis());
        time.add(Calendar.MINUTE, 90);
        timeOut = new Timestamp(time.getTimeInMillis());
    }

    public void setLabelDateAndTime(String tableNo, String time, JLabel tableNum, JLabel reserve) {
        tableNum.setText("");
        reserve.setText("");

        tableNum.setText(tableNo);
        reserve.setText(time);
    }

    public String currentTime() {
        Timer timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                DateFormat timeFormat = new SimpleDateFormat("dd-MM-yyyy   HH:mm:ss");
                Calendar currentTime = new GregorianCalendar();
                currentTime.add(Calendar.YEAR, -543);
                //clock.setText(timeFormat.format(currentTime.getTime()));
                s = timeFormat.format(currentTime.getTime());
            }
        });
        timer.start();
        return s;//clock.settext
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author BestDark
 */
import Model.*;
import View.*;

public class MainController {
    Frame frame;
    
    public void run(){
        frame = new Frame(new Main(this));
        //frame = new Frame(new Reserve(reserve));
    }
    
    public void goToReserve(){
        frame.changeCurrent(new Reserve(new ReserveController()));
    }
    
    public void goToBilling(){
        frame.changeCurrent(new Billing(new BillingController()));//billing
    }
    
    public void goToBacklog(){
        frame.changeCurrent(new Backlog(new BacklogController()));//backlog
    }
    
}

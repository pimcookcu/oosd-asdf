package View;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Administrator
 */
import Controller.BillingController;
import Controller.ReserveController;
import Controller.Reset;
import java.awt.CardLayout;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Reserve extends JPanel implements Reset {

    /**
     * Creates new form CSC319_Reserve
     */
    ReserveController control;
    BillingController c;
    private boolean clickedEnter, clickedADay, clickedAMonth;
    private static int tableId;
    private static java.sql.Timestamp dateTimeReserve, timeOut;
    private int customerId;
    private JPanel current;

    public Reserve() {

    }

    public Reserve(ReserveController c) {
        this.control = c;
        setBounds(0, 80, 975, 688);
        initComponents();
        tblFoodMenu.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                JTable table = (JTable) me.getSource();
                Point p = me.getPoint();
                int row = table.rowAtPoint(p);
                if (me.getClickCount() == 2) {
                    control.delectSelectedRow(tblFoodMenu, lblTotalFoodPrice, lblTotalPrice, row);
                }
            }
        }
        );
        tblBeverageMenu.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                JTable table = (JTable) me.getSource();
                Point p = me.getPoint();
                int row = table.rowAtPoint(p);
                if (me.getClickCount() == 2) {
                    control.delectSelectedRow(tblBeverageMenu, lblTotalBeveragePrice, lblTotalPrice, row);
                }
            }
        }
        );

    }

    public void resetToDefault() {
        tableId = customerId = -1;
        dateTimeReserve = timeOut = null;
        lblTableNo.setText("");
        lblReserve.setText("");
        txtName.setText("");
        lblTotalBeveragePrice.setText("0.0");
        lblTotalFoodPrice.setText("0.0");
        lblTotalPrice.setText("0.0");
        control.deleteAllRow((DefaultTableModel) tblFoodMenu.getModel());
        control.deleteAllRow((DefaultTableModel) tblBeverageMenu.getModel());
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        btnCheck = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        btnSnack = new javax.swing.JButton();
        btnFoods = new javax.swing.JButton();
        btnBeverages = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBeverageMenu = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblFoodMenu = new javax.swing.JTable();
        PDefault = new javax.swing.JPanel();
        lblTotalBeveragePrice = new javax.swing.JLabel();
        lblTotalFoodPrice = new javax.swing.JLabel();
        lblTotalPrice = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblTableNo = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lblReserve = new javax.swing.JLabel();
        btndone = new javax.swing.JButton();
        btnclear = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        btnCheck.setText("Check Table");
        btnCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCheckActionPerformed(evt);
            }
        });

        jLabel1.setText("NAME :");

        txtName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNameActionPerformed(evt);
            }
        });

        btnSnack.setText("Snack");
        btnSnack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSnackActionPerformed(evt);
            }
        });

        btnFoods.setText("Foods");
        btnFoods.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFoodsActionPerformed(evt);
            }
        });

        btnBeverages.setText("Baverage");
        btnBeverages.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBeveragesActionPerformed(evt);
            }
        });

        tblBeverageMenu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                " No", "Beverage", "Price", "Amount", "TotalPrice"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblBeverageMenu.getTableHeader().setReorderingAllowed(false);
        tblBeverageMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBeverageMenuMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblBeverageMenu);
        if (tblBeverageMenu.getColumnModel().getColumnCount() > 0) {
            tblBeverageMenu.getColumnModel().getColumn(0).setResizable(false);
            tblBeverageMenu.getColumnModel().getColumn(1).setResizable(false);
            tblBeverageMenu.getColumnModel().getColumn(2).setResizable(false);
            tblBeverageMenu.getColumnModel().getColumn(3).setResizable(false);
            tblBeverageMenu.getColumnModel().getColumn(4).setResizable(false);
        }

        tblFoodMenu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Food", "Price", "Amount", "Total Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblFoodMenu.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(tblFoodMenu);
        if (tblFoodMenu.getColumnModel().getColumnCount() > 0) {
            tblFoodMenu.getColumnModel().getColumn(0).setResizable(false);
            tblFoodMenu.getColumnModel().getColumn(1).setResizable(false);
            tblFoodMenu.getColumnModel().getColumn(2).setResizable(false);
            tblFoodMenu.getColumnModel().getColumn(3).setResizable(false);
            tblFoodMenu.getColumnModel().getColumn(4).setResizable(false);
        }

        PDefault.setPreferredSize(new java.awt.Dimension(400, 420));

        javax.swing.GroupLayout PDefaultLayout = new javax.swing.GroupLayout(PDefault);
        PDefault.setLayout(PDefaultLayout);
        PDefaultLayout.setHorizontalGroup(
            PDefaultLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        PDefaultLayout.setVerticalGroup(
            PDefaultLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 420, Short.MAX_VALUE)
        );

        lblTotalBeveragePrice.setText("0");

        lblTotalFoodPrice.setText("0");

        lblTotalPrice.setText("0");

        jLabel2.setText("Table No :");

        jLabel4.setText("Reserve No :");

        lblReserve.setText("       ");

        btndone.setText("Done");
        btndone.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btndoneMouseClicked(evt);
            }
        });
        btndone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndoneActionPerformed(evt);
            }
        });

        btnclear.setText("Clear");
        btnclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearActionPerformed(evt);
            }
        });

        jLabel3.setText("Total :");

        jLabel5.setText("Total :");

        jLabel6.setText("Total :");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(114, 114, 114)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(lblTableNo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblReserve, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(PDefault, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                            .addGap(10, 10, 10)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                            .addComponent(btnSnack, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnFoods, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnBeverages, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel6)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(lblTotalPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(lblTotalBeveragePrice, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(lblTotalFoodPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(btndone, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(btnclear, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTotalBeveragePrice)
                            .addComponent(jLabel3))
                        .addGap(35, 35, 35)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblTotalFoodPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTotalPrice)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btndone, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnclear, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(lblTableNo, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(lblReserve))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSnack, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnFoods, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBeverages, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(PDefault, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCheckActionPerformed

    private void txtNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNameActionPerformed

    private void tblBeverageMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBeverageMenuMouseClicked
        if (evt.getClickCount() == 2) {
            int row = tblBeverageMenu.getSelectedRow(); // extend JFrame

            control.delectSelectedRow(tblBeverageMenu, lblTotalBeveragePrice, lblTotalPrice, row);

            System.out.println("hahahahaha");
        }
    }//GEN-LAST:event_tblBeverageMenuMouseClicked

    private void btnclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearActionPerformed
        resetToDefault();
    }//GEN-LAST:event_btnclearActionPerformed

    private void btndoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btndoneActionPerformed

    private void btndoneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btndoneMouseClicked
        if (lblTableNo.getText().equals("") || lblReserve.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Please select table No. and time reserve");
        } else if (txtName.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Please input customer's name");
        } else if (tblFoodMenu.getRowCount() == 0 && tblBeverageMenu.getRowCount() == 0) {
            JOptionPane.showMessageDialog(null, "Please select orders");
        } else {
            //customerId = queue.getCustomerId(txtName.getText());
            control.setOrders(tblFoodMenu.getRowCount(), tblFoodMenu, dateTimeReserve, timeOut, tableId, customerId);
            control.setOrders(tblBeverageMenu.getRowCount(), tblBeverageMenu, dateTimeReserve, timeOut, tableId, customerId);
            //queue.updateStatusTable(tableId);
            resetToDefault();
            JOptionPane.showMessageDialog(null, "Successfully");
        }
    }//GEN-LAST:event_btndoneMouseClicked

    private void btnSnackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSnackActionPerformed
        changeCurrent(new Snack(this.control, this));
    }//GEN-LAST:event_btnSnackActionPerformed

    private void btnFoodsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFoodsActionPerformed
        changeCurrent(new Food(this.control, this));
    }//GEN-LAST:event_btnFoodsActionPerformed

    private void btnBeveragesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBeveragesActionPerformed
        changeCurrent(new Beverage(this.control, this));
    }//GEN-LAST:event_btnBeveragesActionPerformed

    public JLabel getLblTotalBeveragePrice() {
        return lblTotalBeveragePrice;
    }

    public JLabel getLblTotalFoodPrice() {
        return lblTotalFoodPrice;
    }

    public JLabel getLblTotalPrice() {
        return lblTotalPrice;
    }

    public JTable getTblBeverageMenu() {
        return tblBeverageMenu;
    }

    public JTable getTblFoodMenu() {
        return tblFoodMenu;
    }

    public void changeCurrent(JPanel panel) {
        if (current != null) {
            PDefault.remove(current);
        }
        PDefault.add(current = panel);
        validate();
        repaint();

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PDefault;
    private javax.swing.JButton btnBeverages;
    private javax.swing.JButton btnCheck;
    private javax.swing.JButton btnFoods;
    private javax.swing.JButton btnSnack;
    private javax.swing.JButton btnclear;
    private javax.swing.JButton btndone;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblReserve;
    private javax.swing.JLabel lblTableNo;
    public javax.swing.JLabel lblTotalBeveragePrice;
    public javax.swing.JLabel lblTotalFoodPrice;
    public javax.swing.JLabel lblTotalPrice;
    public javax.swing.JTable tblBeverageMenu;
    public javax.swing.JTable tblFoodMenu;
    private javax.swing.JTextField txtName;
    // End of variables declaration//GEN-END:variables

}

package View;

import Controller.ReserveController;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;

public class Snack extends JPanel{
    
    ReserveController control;
    JLabel lblTotalPrice;
    JLabel lblTotalFoodPrice;
    JLabel lblTotalBeveragePrice;
    JTable tblBeverageMenu;
    JTable tblFoodMenu;
    
    public Snack(ReserveController c,Reserve r) {
        this.control = c;
        this.lblTotalPrice = r.getLblTotalPrice();
        this.lblTotalBeveragePrice = r.getLblTotalBeveragePrice();
        this.lblTotalFoodPrice = r.getLblTotalFoodPrice();
        this.tblBeverageMenu = r.getTblBeverageMenu();
        this.tblFoodMenu = r.getTblFoodMenu();
        initComponents();
        setBounds(0,0,400,420);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnFriedFishPasteBalls = new javax.swing.JButton();
        btnCharcoalBoiledPorkNeck = new javax.swing.JButton();
        btnFriedChicken = new javax.swing.JButton();
        btnFriedPorkRind = new javax.swing.JButton();
        btnCrispyWonton = new javax.swing.JButton();
        btnSteamedSpringRoll = new javax.swing.JButton();

        setMaximumSize(new java.awt.Dimension(400, 420));
        setMinimumSize(new java.awt.Dimension(400, 420));
        setPreferredSize(new java.awt.Dimension(400, 420));

        btnFriedFishPasteBalls.setText("Fried Fish-Paste Balls");
        btnFriedFishPasteBalls.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnFriedFishPasteBallsMouseClicked(evt);
            }
        });
        btnFriedFishPasteBalls.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFriedFishPasteBallsActionPerformed(evt);
            }
        });

        btnCharcoalBoiledPorkNeck.setText("Charcoal-Boiled Pork Neck");
        btnCharcoalBoiledPorkNeck.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCharcoalBoiledPorkNeckMouseClicked(evt);
            }
        });
        btnCharcoalBoiledPorkNeck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCharcoalBoiledPorkNeckActionPerformed(evt);
            }
        });

        btnFriedChicken.setText("Fried Chicken");
        btnFriedChicken.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnFriedChickenMouseClicked(evt);
            }
        });
        btnFriedChicken.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFriedChickenActionPerformed(evt);
            }
        });

        btnFriedPorkRind.setText("Fried Pork Rind");
        btnFriedPorkRind.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnFriedPorkRindMouseClicked(evt);
            }
        });
        btnFriedPorkRind.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFriedPorkRindActionPerformed(evt);
            }
        });

        btnCrispyWonton.setText("Crispy Wonton");
        btnCrispyWonton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCrispyWontonMouseClicked(evt);
            }
        });
        btnCrispyWonton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrispyWontonActionPerformed(evt);
            }
        });

        btnSteamedSpringRoll.setText("Steamed Spring Roll");
        btnSteamedSpringRoll.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSteamedSpringRollMouseClicked(evt);
            }
        });
        btnSteamedSpringRoll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSteamedSpringRollActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnFriedFishPasteBalls, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCharcoalBoiledPorkNeck, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnFriedChicken, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnFriedPorkRind, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSteamedSpringRoll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCrispyWonton, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(57, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(btnFriedFishPasteBalls, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCharcoalBoiledPorkNeck, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnFriedChicken, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnFriedPorkRind, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSteamedSpringRoll, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCrispyWonton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(83, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnFriedPorkRindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFriedPorkRindActionPerformed

    }//GEN-LAST:event_btnFriedPorkRindActionPerformed

    private void btnCrispyWontonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrispyWontonActionPerformed

    }//GEN-LAST:event_btnCrispyWontonActionPerformed

    private void btnFriedFishPasteBallsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFriedFishPasteBallsMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnFriedFishPasteBalls, 85.0);
    }//GEN-LAST:event_btnFriedFishPasteBallsMouseClicked

    private void btnCharcoalBoiledPorkNeckMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCharcoalBoiledPorkNeckMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnCharcoalBoiledPorkNeck, 110.0);
    }//GEN-LAST:event_btnCharcoalBoiledPorkNeckMouseClicked

    private void btnFriedChickenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFriedChickenMouseClicked
       control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnFriedChicken, 60.0);
    }//GEN-LAST:event_btnFriedChickenMouseClicked

    private void btnFriedPorkRindMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFriedPorkRindMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnFriedPorkRind, 70.0);
    }//GEN-LAST:event_btnFriedPorkRindMouseClicked

    private void btnCrispyWontonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCrispyWontonMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnCrispyWonton, 60.0);
    }//GEN-LAST:event_btnCrispyWontonMouseClicked

    private void btnSteamedSpringRollMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSteamedSpringRollMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnSteamedSpringRoll, 15.0);
    }//GEN-LAST:event_btnSteamedSpringRollMouseClicked

    private void btnCharcoalBoiledPorkNeckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCharcoalBoiledPorkNeckActionPerformed

    }//GEN-LAST:event_btnCharcoalBoiledPorkNeckActionPerformed

    private void btnSteamedSpringRollActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSteamedSpringRollActionPerformed

    }//GEN-LAST:event_btnSteamedSpringRollActionPerformed

    private void btnFriedChickenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFriedChickenActionPerformed

    }//GEN-LAST:event_btnFriedChickenActionPerformed

    private void btnFriedFishPasteBallsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFriedFishPasteBallsActionPerformed

    }//GEN-LAST:event_btnFriedFishPasteBallsActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCharcoalBoiledPorkNeck;
    private javax.swing.JButton btnCrispyWonton;
    private javax.swing.JButton btnFriedChicken;
    private javax.swing.JButton btnFriedFishPasteBalls;
    private javax.swing.JButton btnFriedPorkRind;
    private javax.swing.JButton btnSteamedSpringRoll;
    // End of variables declaration//GEN-END:variables
}

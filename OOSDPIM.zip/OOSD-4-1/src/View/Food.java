package View;

import Controller.ReserveController;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;

public class Food extends JPanel{
    
    ReserveController control;
    JLabel lblTotalPrice;
    JLabel lblTotalFoodPrice;
    JLabel lblTotalBeveragePrice;
    JTable tblBeverageMenu;
    JTable tblFoodMenu;
    
    public Food(ReserveController c,Reserve r) {
        this.control = c;
        this.lblTotalPrice = r.getLblTotalPrice();
        this.lblTotalBeveragePrice = r.getLblTotalBeveragePrice();
        this.lblTotalFoodPrice = r.getLblTotalFoodPrice();
        this.tblBeverageMenu = r.getTblBeverageMenu();
        this.tblFoodMenu = r.getTblFoodMenu();
        initComponents();
        setBounds(0,0,400,420);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnRice = new javax.swing.JButton();
        btnCharcoalBoiledPorkNeck = new javax.swing.JButton();
        btnSteamedDuck = new javax.swing.JButton();
        btnFriedFishToppedWithChilliSauce = new javax.swing.JButton();
        btnChickenGreenCurry = new javax.swing.JButton();
        btnSpicyVermicelliSalad = new javax.swing.JButton();

        setMaximumSize(new java.awt.Dimension(400, 420));
        setMinimumSize(new java.awt.Dimension(400, 420));
        setPreferredSize(new java.awt.Dimension(400, 420));

        btnRice.setText("Rice");
        btnRice.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRiceMouseClicked(evt);
            }
        });
        btnRice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRiceActionPerformed(evt);
            }
        });

        btnCharcoalBoiledPorkNeck.setText("Casseroled Prawns");
        btnCharcoalBoiledPorkNeck.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCharcoalBoiledPorkNeckMouseClicked(evt);
            }
        });
        btnCharcoalBoiledPorkNeck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCharcoalBoiledPorkNeckActionPerformed(evt);
            }
        });

        btnSteamedDuck.setText("Steamed Duck");
        btnSteamedDuck.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSteamedDuckMouseClicked(evt);
            }
        });
        btnSteamedDuck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSteamedDuckActionPerformed(evt);
            }
        });

        btnFriedFishToppedWithChilliSauce.setText("FriedFish Topped With ChilliSauce");
        btnFriedFishToppedWithChilliSauce.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnFriedFishToppedWithChilliSauceMouseClicked(evt);
            }
        });
        btnFriedFishToppedWithChilliSauce.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFriedFishToppedWithChilliSauceActionPerformed(evt);
            }
        });

        btnChickenGreenCurry.setText("Chicken GreenCurry");
        btnChickenGreenCurry.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnChickenGreenCurryMouseClicked(evt);
            }
        });
        btnChickenGreenCurry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChickenGreenCurryActionPerformed(evt);
            }
        });

        btnSpicyVermicelliSalad.setText("Spicy Vermicelli Salad");
        btnSpicyVermicelliSalad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSpicyVermicelliSaladMouseClicked(evt);
            }
        });
        btnSpicyVermicelliSalad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSpicyVermicelliSaladActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnRice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCharcoalBoiledPorkNeck, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSteamedDuck, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnFriedFishToppedWithChilliSauce, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSpicyVermicelliSalad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnChickenGreenCurry, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(57, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(btnRice, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCharcoalBoiledPorkNeck, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSteamedDuck, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnFriedFishToppedWithChilliSauce, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSpicyVermicelliSalad, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnChickenGreenCurry, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(83, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnFriedFishToppedWithChilliSauceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFriedFishToppedWithChilliSauceActionPerformed

    }//GEN-LAST:event_btnFriedFishToppedWithChilliSauceActionPerformed

    private void btnChickenGreenCurryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChickenGreenCurryActionPerformed

    }//GEN-LAST:event_btnChickenGreenCurryActionPerformed

    private void btnRiceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRiceMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnRice, 85.0);
    }//GEN-LAST:event_btnRiceMouseClicked

    private void btnCharcoalBoiledPorkNeckMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCharcoalBoiledPorkNeckMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnCharcoalBoiledPorkNeck, 110.0);
    }//GEN-LAST:event_btnCharcoalBoiledPorkNeckMouseClicked

    private void btnSteamedDuckMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSteamedDuckMouseClicked
       control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnSteamedDuck, 60.0);
    }//GEN-LAST:event_btnSteamedDuckMouseClicked

    private void btnFriedFishToppedWithChilliSauceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFriedFishToppedWithChilliSauceMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnFriedFishToppedWithChilliSauce, 70.0);
    }//GEN-LAST:event_btnFriedFishToppedWithChilliSauceMouseClicked

    private void btnChickenGreenCurryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnChickenGreenCurryMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnChickenGreenCurry, 60.0);
    }//GEN-LAST:event_btnChickenGreenCurryMouseClicked

    private void btnSpicyVermicelliSaladMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSpicyVermicelliSaladMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalFoodPrice, tblFoodMenu, btnSpicyVermicelliSalad, 15.0);
    }//GEN-LAST:event_btnSpicyVermicelliSaladMouseClicked

    private void btnCharcoalBoiledPorkNeckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCharcoalBoiledPorkNeckActionPerformed

    }//GEN-LAST:event_btnCharcoalBoiledPorkNeckActionPerformed

    private void btnSpicyVermicelliSaladActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSpicyVermicelliSaladActionPerformed

    }//GEN-LAST:event_btnSpicyVermicelliSaladActionPerformed

    private void btnSteamedDuckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSteamedDuckActionPerformed

    }//GEN-LAST:event_btnSteamedDuckActionPerformed

    private void btnRiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRiceActionPerformed

    }//GEN-LAST:event_btnRiceActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCharcoalBoiledPorkNeck;
    private javax.swing.JButton btnChickenGreenCurry;
    private javax.swing.JButton btnFriedFishToppedWithChilliSauce;
    private javax.swing.JButton btnRice;
    private javax.swing.JButton btnSpicyVermicelliSalad;
    private javax.swing.JButton btnSteamedDuck;
    // End of variables declaration//GEN-END:variables
}

package View;

import Controller.ReserveController;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;

public class Beverage extends JPanel{
    
    ReserveController control;
    JLabel lblTotalPrice;
    JLabel lblTotalFoodPrice;
    JLabel lblTotalBeveragePrice;
    JTable tblBeverageMenu;
    JTable tblFoodMenu;
    
    public Beverage(ReserveController c,Reserve r) {
        this.control = c;
        this.lblTotalPrice = r.getLblTotalPrice();
        this.lblTotalBeveragePrice = r.getLblTotalBeveragePrice();
        this.lblTotalFoodPrice = r.getLblTotalFoodPrice();
        this.tblBeverageMenu = r.getTblBeverageMenu();
        this.tblFoodMenu = r.getTblFoodMenu();
        initComponents();
        setBounds(0,0,400,420);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnWater = new javax.swing.JButton();
        btnPepsi = new javax.swing.JButton();
        btnSprite = new javax.swing.JButton();
        btnFanta = new javax.swing.JButton();
        btnGreenTea = new javax.swing.JButton();
        btnSoda = new javax.swing.JButton();

        setMaximumSize(new java.awt.Dimension(400, 420));
        setMinimumSize(new java.awt.Dimension(400, 420));
        setPreferredSize(new java.awt.Dimension(400, 420));

        btnWater.setText("Water");
        btnWater.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnWaterMouseClicked(evt);
            }
        });
        btnWater.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWaterActionPerformed(evt);
            }
        });

        btnPepsi.setText("Pepsi");
        btnPepsi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnPepsiMouseClicked(evt);
            }
        });
        btnPepsi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPepsiActionPerformed(evt);
            }
        });

        btnSprite.setText("Sprite");
        btnSprite.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSpriteMouseClicked(evt);
            }
        });
        btnSprite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSpriteActionPerformed(evt);
            }
        });

        btnFanta.setText("Fanta");
        btnFanta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnFantaMouseClicked(evt);
            }
        });
        btnFanta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFantaActionPerformed(evt);
            }
        });

        btnGreenTea.setText("GreenTea");
        btnGreenTea.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGreenTeaMouseClicked(evt);
            }
        });
        btnGreenTea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGreenTeaActionPerformed(evt);
            }
        });

        btnSoda.setText("Soda");
        btnSoda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSodaMouseClicked(evt);
            }
        });
        btnSoda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSodaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnWater, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnPepsi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSprite, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnFanta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSoda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnGreenTea, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(57, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(btnWater, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPepsi, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSprite, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnFanta, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSoda, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnGreenTea, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(83, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnFantaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFantaActionPerformed

    }//GEN-LAST:event_btnFantaActionPerformed

    private void btnGreenTeaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGreenTeaActionPerformed

    }//GEN-LAST:event_btnGreenTeaActionPerformed

    private void btnWaterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnWaterMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalBeveragePrice, tblBeverageMenu, btnWater,15.0);
    }//GEN-LAST:event_btnWaterMouseClicked

    private void btnPepsiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPepsiMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalBeveragePrice, tblBeverageMenu, btnPepsi, 110.0);
    }//GEN-LAST:event_btnPepsiMouseClicked

    private void btnSpriteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSpriteMouseClicked
       control.addtblMenuLine(lblTotalPrice, lblTotalBeveragePrice, tblBeverageMenu, btnSprite, 60.0);
    }//GEN-LAST:event_btnSpriteMouseClicked

    private void btnFantaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFantaMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalBeveragePrice, tblBeverageMenu, btnFanta, 70.0);
    }//GEN-LAST:event_btnFantaMouseClicked

    private void btnGreenTeaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGreenTeaMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalBeveragePrice, tblBeverageMenu, btnGreenTea, 60.0);
    }//GEN-LAST:event_btnGreenTeaMouseClicked

    private void btnSodaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSodaMouseClicked
        control.addtblMenuLine(lblTotalPrice, lblTotalBeveragePrice, tblBeverageMenu, btnSoda, 15.0);
    }//GEN-LAST:event_btnSodaMouseClicked

    private void btnPepsiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPepsiActionPerformed

    }//GEN-LAST:event_btnPepsiActionPerformed

    private void btnSodaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSodaActionPerformed

    }//GEN-LAST:event_btnSodaActionPerformed

    private void btnSpriteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSpriteActionPerformed

    }//GEN-LAST:event_btnSpriteActionPerformed

    private void btnWaterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWaterActionPerformed

    }//GEN-LAST:event_btnWaterActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFanta;
    private javax.swing.JButton btnGreenTea;
    private javax.swing.JButton btnPepsi;
    private javax.swing.JButton btnSoda;
    private javax.swing.JButton btnSprite;
    private javax.swing.JButton btnWater;
    // End of variables declaration//GEN-END:variables
}
